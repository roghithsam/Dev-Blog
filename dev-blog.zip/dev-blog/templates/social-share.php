<style type="text/css">
  .social-share {
  margin-top: 20px;
}

.social-share h2 {
  font-size: 18px;
  font-weight: bold;
}

.social-share-buttons {
  list-style: none;
  padding: 0;
  margin: 0;
  display: flex;
}

.social-share-buttons li {
  margin-right: 10px;
}

.social-share-buttons li:last-child {
  margin-right: 0;
}

.social-share-buttons a {
  display: flex;
  align-items: center;
  font-size: 14px;
  color: #333;
  text-decoration: none;
  transition: color 0.3s;
}

.social-share-buttons a:hover {
  color: #007bff;
}

.social-share-buttons i {
  margin-right: 5px;
}

.social-share-buttons .fas,
.social-share-buttons .fab {
  font-size: 18px;
}

.social-share-buttons .fa-link {
  font-size: 14px;
}

</style>

<section class="social-share">
  
  <h2>Share this post</h2>
  <ul class="social-share-buttons">
    <li>
      <a href="whatsapp://send?text=<?php echo urlencode(get_the_title() . ' - ' . get_permalink()); ?>" target="_blank" rel="nofollow">
        <i class="fab fa-whatsapp"></i> WhatsApp
      </a>
    </li>
    <li>
      <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode(get_permalink()); ?>" target="_blank" rel="nofollow">
        <i class="fab fa-facebook"></i> Facebook
      </a>
    </li>
    <li>
      <a href="mailto:?subject=<?php echo urlencode(get_the_title()); ?>&amp;body=<?php echo urlencode(get_permalink()); ?>" target="_blank" rel="nofollow">
        <i class="fas fa-envelope"></i> Email
      </a>
    </li>
    <li>
      <a href="https://twitter.com/intent/tweet?text=<?php echo urlencode(get_the_title()); ?>&amp;url=<?php echo urlencode(get_permalink()); ?>" target="_blank" rel="nofollow">
        <i class="fab fa-twitter"></i> Twitter
      </a>
    </li>
    <li>
      <a href="#" onclick="copyToClipboard('<?php echo get_permalink(); ?>'); return false;">
        <i class="fas fa-link"></i> Copy Link
      </a>
    </li>
  </ul>
</section>

<script>
  function copyToClipboard(text) {
    var input = document.createElement('textarea');
    input.innerHTML = text;
    document.body.appendChild(input);
    input.select();
    document.execCommand('copy');
    document.body.removeChild(input);
    alert('Link copied to clipboard!');
  }
</script>
