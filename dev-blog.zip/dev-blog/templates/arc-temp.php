

<!-- BLOG SECTION -->

<div class="blog">
	 <h2 class="h2">Latest Blog Post</h2>

	<div class="blog-card-group" id="loadData">

		<?php 
if ( have_posts() ) {
		while ( have_posts() ) {

			the_post(); 

			?>

			<div class="blog-card">

				<div class="blog-card-banner">

					<?php if (has_post_thumbnail()){ ?>

							<a href="<?php the_permalink(); ?>"></a>
							<?php 

							$thumbnail_attributes = array(
								'class' => 'blog-banner-img',
								'width' => '250',

							);
							the_post_thumbnail('thumbnail', $thumbnail_attributes);

						 }else{
						 	echo '<img src="'. get_template_directory_uri() .'/assets/images/ben.png" alt="' . get_bloginfo( 'name' ) . '"  width="250" class="blog-head-img">';
						 } ?>

				</div>

				<div class="blog-content-wrapper">


					<?php
					$categories = get_the_category();
					$cnt = 0; 
					foreach ($categories as $category) {
						$cnt += 1;
						if ($cnt <=2 ) {
						echo '<a href="' . esc_url(get_category_link($category->term_id)) . '"><button class="blog-topic text-tiny">' . $category->name . '</button></a> ';
					}
					}
					?>

					<h3>
						<a href="<?php the_permalink(); ?>" class="h3">
							<?php the_title(); ?>
						</a>
					</h3>

					<div class="blog-text">

						<?php 
							$excerpt = get_the_excerpt(); 
							$excerpt = substr( $excerpt, 0, 250 ); // Only display first 260 characters of excerpt
							$result = substr( $excerpt, 0, strrpos( $excerpt, ' ' ) );
						    echo $result; 
						    echo '<a class="pull-right" href="<?php the_permalink(); ?>"><span style="
							right: 5px; bottom: 5px;">Read more...</span></a>';
						?>
					</div>
					 <?php if (get_theme_mod('display_author_details', true)) { ?>
					<hr>
					<div class="wrapper-flex">

						<div class="profile-wrapper">
							<?php echo get_avatar(get_the_author_meta('user_email'), '50'); ?>
						</div>

						<div class="wrapper">
							<a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID')));   ?>" class="h4"> <?php the_author(); ?> </a>

						

							<p class="text-sm">
								<i class="fa fa-calendar"></i>
								<time><?php the_time('F j, Y'); ?> </time>
								<span class="separator"></span>
								<i class="fa fa-clock"></i>
								<time><?php the_time('g:i a'); ?></time>
							</p>
                            
							
						</div>

						

					</div>

					<?php }?>

				</div>

			</div>

			<?php

		} 
}
		?>


	</div>

</div>

	