<?php
// Prevent direct access to this file
if (!empty($_SERVER['SCRIPT_FILENAME']) && 'comments.php' == basename($_SERVER['SCRIPT_FILENAME'])) {
    die('Please do not load this page directly. Thanks!');
}

if (post_password_required()) {
    return;
}
?>

<div id="comments" class="comments-area">
    <?php if (have_comments()) : ?>
        <h2 class="comments-title">
            <?php
            $comments_number = get_comments_number();
            if ('1' === $comments_number) {
                printf(_x('One comment', 'comments title', 'your-theme-textdomain'));
            } else {
                printf(_nx('%s comment', '%s comments', $comments_number, 'comments title', 'your-theme-textdomain'), number_format_i18n($comments_number));
            }
            ?>
        </h2>

        <ol class="comment-list">
            <?php
            wp_list_comments(
                array(
                    'style'       => 'ol',
                    'short_ping'  => true,
                    'avatar_size' => 50,
                )
            );
            ?>
        </ol>

        <?php if (get_comment_pages_count() > 1 && get_option('page_comments')) : ?>
            <nav class="comment-navigation" role="navigation">
                <div class="comment-nav-prev"><?php previous_comments_link(__('Older Comments', 'your-theme-textdomain')); ?></div>
                <div class="comment-nav-next"><?php next_comments_link(__('Newer Comments', 'your-theme-textdomain')); ?></div>
            </nav>
        <?php endif; ?>

    <?php endif; ?>

    <?php
    $comment_form_args = array(
        'comment_notes_after' => '',
        'fields'              => array(
            'author' => '<p class="comment-form-author">' . '<label for="author">' . __('Name', 'your-theme-textdomain') . ' <span class="required">*</span></label> ' .
                        '<input id="author" name="author" type="text" value="' . esc_attr($commenter['comment_author']) . '" size="30" required /></p>',
            'email'  => '<p class="comment-form-email">' . '<label for="email">' . __('Email', 'your-theme-textdomain') . ' <span class="required">*</span></label> ' .
                        '<input id="email" name="email" type="email" value="' . esc_attr($commenter['comment_author_email']) . '" size="30" required /></p>',
            'url'    => '<p class="comment-form-url">' . '<label for="url">' . __('Website', 'your-theme-textdomain') . '</label>' .
                        '<input id="url" name="url" type="url" value="' . esc_attr($commenter['comment_author_url']) . '" size="30" /></p>',
        ),
        'comment_field'        => '<p class="comment-form-comment">' . '<label for="comment">' . __('Comment', 'your-theme-textdomain') . '</label>' .
                                '<textarea id="comment" name="comment" cols="45" rows="8" required></textarea></p>',
        'must_log_in'          => '<p class="must-log-in">' . sprintf(__('You must be <a href="%s">logged in</a> to post a comment.', 'your-theme-textdomain'), wp_login_url(apply_filters('the_permalink', get_permalink()))) . '</p>',
        'logged_in_as'         => '<p class="logged-in-as">' . sprintf(__('Logged in as <a href="%1$s">%2$s</a>. <a href="%3$s" title="Log out of this account">Log out?</a>', 'your-theme-textdomain'), get_edit_user_link(), $user_identity, wp_logout_url(apply_filters('the_permalink', get_permalink()))) . '</p>',
        'comment_notes_before' => '',
        'submit_button'        => '<p class="form-submit">' . '<input name="%1$s" type="submit" id="%2$s" class="%3$s" value="%4$s" /></p>',
    );

    comment_form($comment_form_args);
    ?>
</div>
