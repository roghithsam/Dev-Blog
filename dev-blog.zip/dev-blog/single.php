<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */
 
get_header(); // Include the header template
?>

<?php while (have_posts()) : the_post(); ?>
  <article <?php post_class(); ?>>
    <header>
      <h1><?php the_title(); ?></h1>
      <div class="post-meta">
        <span class="post-date"><?php the_date(); ?></span>
        <span class="post-author"><?php the_author(); ?></span>
        <span class="post-views"><?php echo do_shortcode( '[post-views]' ); ?> Views</span>
      </div>
    </header>
    <div class="post-content">
      <?php the_content(); ?>
    </div>
  </article>

  <section class="related-posts">
    <h2>Related Posts</h2>
    <?php
    // Query related posts based on categories or tags
    $related_posts = new WP_Query(array(
      'posts_per_page' => 3,
      'post__not_in' => array(get_the_ID()),
      'category__in' => wp_get_post_categories(get_the_ID()),
      'orderby' => 'rand',
    ));

    if ($related_posts->have_posts()) :
      while ($related_posts->have_posts()) : $related_posts->the_post();
    ?>
        <div class="related-post">
          <h3><?php the_title(); ?></h3>
          <div class="related-post-excerpt"><?php the_excerpt(); ?></div>
          <a href="<?php the_permalink(); ?>" class="read-more">Read More</a>
        </div>
    <?php
      endwhile;
      wp_reset_postdata();
    else :
      echo 'No related posts found.';
    endif;
    ?>
  </section>

  <section class="comments-section">
    <h2>Comments</h2>
    <?php comments_template(); ?>
  </section>

  <section class="social-share">
    <h2>Share this post</h2>
    <?php
   get_template_part( 'templates/social-share' );
    ?>
  </section>

<?php 
   // Previous/next post navigation.
            the_post_navigation( array(
                'next_text' => '<span class="meta-nav" aria-hidden="true">' . __( 'Next', 'twentyfifteen' ) . '</span> ' .
                    '<span class="screen-reader-text">' . __( 'Next post:', 'twentyfifteen' ) . '</span> ' .
                    '<span class="post-title">%title</span>',
                'prev_text' => '<span class="meta-nav" aria-hidden="true">' . __( 'Previous', 'twentyfifteen' ) . '</span> ' .
                    '<span class="screen-reader-text">' . __( 'Previous post:', 'twentyfifteen' ) . '</span> ' .
                    '<span class="post-title">%title</span>',
            ) );
?>

<?php endwhile; ?>

<?php get_footer(); // Include the footer template ?>
