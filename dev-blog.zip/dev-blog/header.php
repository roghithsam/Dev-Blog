<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.css">
	<?php wp_head(); ?>
</head>
<body class="light-theme" <?php body_class(); ?> >

	
	<?php wp_body_open(); ?>

 <!-- <div id="preloader-wrapperaa">
         <div id="preloaderaa"></div>
</div>
-->
<a class="skip-link screen-reader-text" href="#content">
	<?php
	/* translators: Hidden accessibility text. */
	esc_html_e( 'Skip to content', 'twentytwentyone' );
	?>
</a>

<header>

	<?php get_template_part( 'includes/top-bar' ); 

	get_template_part( 'includes/main-menu' );

	?>

</header>


<hr>

		


