<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */
 
get_header(); // Include the header template
?>

<?php
 while (have_posts()) : the_post(); ?>
<main>

   <div class="hero">

    <?php

    if (has_post_thumbnail()) {
      $post_thumbnail_url = get_the_post_thumbnail_url(get_the_ID(), 'full'); // You can change 'full' to other image size if needed
      if ($post_thumbnail_url) {
        ?>
        <div id="page-header" class="blog-header" <?php echo 'style="background-image:url('.esc_url($post_thumbnail_url).');"'; ?>>
          <?php the_title( '<h2 class="h2">', '</h2>' ); 

  // Single.php, Archive.php, Sidebar.php, or any other template file
          if (has_excerpt()) {
            $post_excerpt = get_the_excerpt();
            echo '<p class="blog-text">' . esc_html($post_excerpt) . '</p>';
          }
          ?>
        </div>
        <?php

      }
    }
    ?>

  </div>

         <div class="main">

           <div class="container">

             <div class="blog">

              <article <?php post_class(); ?>>

              <?php
               if (get_theme_mod('display_post_tags_details', true)) {
                          // Display post tags
              $tags = get_the_tags();
              if ($tags) {
                echo '<div class="post-tags bw-text">Tagged as: ';
                foreach ($tags as $tag) {
                  echo '<a href="' . get_tag_link($tag->term_id) . '">' . $tag->name . '</a>, ';
                }
                echo '</div>';
              }
            }
              ?>

              <div class="post-meta">
                <span class="post-date"><?php the_date(); ?></span>
                <span class="post-author"><?php the_author(); ?></span>
                <!-- <span class="post-views"><?php echo do_shortcode( '[post-views]' ); ?> Views</span> -->
              </div>


              <h2 class="h2"><?php the_title(); ?></h2>

              <?php 
               if (get_theme_mod('display_post_image_details', true)) {

                if (has_post_thumbnail()) {
                $thumbnail_attributes = array(
                  'alt' => '"'. esc_attr(get_the_title()). '"',
                  'class' => 'blog-head-img',
                  'width' => '250',

                );
                the_post_thumbnail('thumbnail', $thumbnail_attributes);

              }else{
                    echo '<img src="'. get_template_directory_uri() .'/assets/images/ben.png" alt="' . get_bloginfo( 'name' ) . '"  width="250" class="blog-head-img">';
                   }
            }
              ?>


              <div class="blog-card-group">

               <div class="m-blog-card">

                 <div class="blog-page-text bw-text">

                  <?php the_content(); ?>

                </div>


              </div>

            </div>

          </article>

            <div id="np">
            
             <?php  

              if (get_theme_mod('display_post_next-pre_details', true)) {

              // Previous and next post links 
            // the_post_navigation(); 
      $previous_post_link = get_previous_post_link('<div class="btn load-more">%link</div>', 'Previous Post', false);
$next_post_link = get_next_post_link('<div class="btn load-more">%link</div>', 'Next Post', false);


    echo $previous_post_link; 
    echo $next_post_link; 
  }
  ?>

            

           </div>

        <?php 
      

  if (get_theme_mod('display_note_details', true)) {
  
      echo '<h2 class="h2">Related Notes</h2><div id="np" class="ovf">';

               echo '<div id="note_" class="m-blog-card">

               <div class="blog-content-wrapper">
               <h3 class="h3">
               TItle
               </a>
               </h3>

               <p class="blog-text">
               Content
               </p>
               <hr>
               
               <div class="bottom-content wrapper-flex">
               <span class="text-sm">January 1, 2023</span>
               <div class="settings">
               <i onclick="showMenu(this)" class="fa fa-ellipsis-h"></i>
               <ul class="menu2">
               <li onclick="deleteNote("8")"><i class="fa fa-trash"></i>Delete</li>
               </ul>
               </div>
               </div>

               </div>

               </div>';
          
     
      echo '</div>';
  }
  ?>

<?php

 if (get_theme_mod('display_related_post_details', true)) {
   // Related posts by category
            $categories = get_the_category();
            if ($categories) {
                $category_ids = array();
                foreach ($categories as $category) {
                    $category_ids[] = $category->term_id;
                }

                $args = array(
                    'category__in' => $category_ids,
                    'post__not_in' => array(get_the_ID()),
                    'posts_per_page' => 2,
                    'orderby' => 'rand',
                );

                $related_posts = new WP_Query($args);
                if ($related_posts->have_posts()) {
                    echo '<h2 class="h2">Related Posts</h2>';
                    echo '<div id="np" class="ovf related-posts">';
                    while ($related_posts->have_posts()) {
                        $related_posts->the_post();
                        ?>
                        <div class="m-blog-card"> 
                   <div class="blog-card-banner">

                <?php if (has_post_thumbnail()) { ?>
                    <a href="<?php the_permalink(); ?>"></a>
                    <?php 

                    $thumbnail_attributes = array(
                      'class' => 'blog-banner-img',
                      'width' => '250',

                    );
                    the_post_thumbnail('thumbnail', $thumbnail_attributes);

                    ?>
                <?php }else{
                    echo '<img src="'. get_template_directory_uri() .'/assets/images/ben.png" alt="' . get_bloginfo( 'name' ) . '"  width="250" class="blog-head-img">';
                   }?>

              </div>

              <div class="blog-content-wrapper">


                <?php
                $cnt = 0; 
                $categories = get_the_category();
                foreach ($categories as $category) {
                  $cnt += 1;
                  if ($cnt <=2 ) {
                  echo '<a href="' . esc_url(get_category_link($category->term_id)) . '"><button class="blog-topic text-tiny">' . $category->name . '</button></a> ';
                }
                }
                ?>

                <h3>
                  <a href="<?php the_permalink(); ?>" class="h3">
                    <?php the_title(); ?>
                  </a>
                </h3>

                <div class="blog-text">

                  <?php 
                    $excerpt = get_the_excerpt(); 
                    $excerpt = substr( $excerpt, 0, 250 ); // Only display first 260 characters of excerpt
                    $result = substr( $excerpt, 0, strrpos( $excerpt, ' ' ) );
                      echo $result; 
                      echo '<a class="pull-right" href="<?php the_permalink(); ?>"><span style="
                    right: 5px; bottom: 5px;">Read more...</span></a>';
                  ?>
                </div>
                 <?php if (get_theme_mod('display_author_details', true)) : ?>
                <hr>
                <div class="wrapper-flex">

                  <div class="profile-wrapper">
                    <?php echo get_avatar(get_the_author_meta('user_email'), '50'); ?>
                  </div>

                  <div class="wrapper">
                    <a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID')));   ?>" class="h4"> <?php the_author(); ?> </a>

                  

                    <p class="text-sm">
                      <i class="fa fa-calendar"></i>
                      <time><?php the_time('F j, Y'); ?> </time>
                      <span class="separator"></span>
                      <i class="fa fa-clock"></i>
                      <time><?php the_time('g:i a'); ?></time>
                    </p>
                                        
                    
                  </div>

                  

                </div>

                <?php endif; ?>
 
              </div>

            </div>
                        <?php
                    }
                    echo '</div>';
                }else{
                  echo '<div class="m-blog-card"><p class="blog-text">No Posts To Fetch</p></div>';
                }
                wp_reset_postdata();
            }
        }
        ?>
            
<?php if (get_theme_mod('display_post_share_details', true)) { ?>
 <p><strong>Share </strong></p>
 <!-- Add this code where you want to display the share buttons -->
<div class="post-share-buttons">
    <a class="share-twitter" href="https://twitter.com/intent/tweet?text=<?php echo urlencode(get_the_title()); ?>&amp;url=<?php echo urlencode(get_permalink()); ?>" title="Share on Twitter"><i class="fab fa-twitter"></i></a>
    <a class="share-facebook" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode(get_permalink()); ?>" title="Share on Facebook"><i class="fab fa-facebook"></i></a>
    <a class="share-whatsapp" href="whatsapp://send?text=<?php echo urlencode(get_the_title() . ' - ' . get_permalink()); ?>" title="Share on WhatsApp"><i class="fab fa-whatsapp"></i></a>
    <a class="share-email" href="mailto:?subject=<?php echo urlencode(get_the_title()); ?>&amp;body=<?php echo urlencode(get_permalink()); ?>" title="Share via Email"><i class="fas fa-envelope"></i></a>
    <!-- <a class="copy-link" href="#" title="Copy Link"><i class="fas fa-copy"></i></a>
    --><a class="copy-link" href="#" onclick="copyToClipboard('<?php echo get_permalink(); ?>'); return false;">
        <i class="fas fa-copy"></i>
      </a>
</div>
<style type="text/css">
  /* Add this CSS to style the share buttons */
.post-share-buttons {
    display: flex;
margin-bottom:20px; }

.post-share-buttons a {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    margin-right: 10px;
    border-radius: 50%;
    background-color: #333;
    color: #fff;
    text-decoration: none;
    font-size: 18px;
}

.post-share-buttons a:hover {
    background-color: #007bff;
}

</style>
<!-- Add this JavaScript code after the share buttons HTML -->
<script>
  function copyToClipboard(text) {
    var input = document.createElement('textarea');
    input.innerHTML = text;
    document.body.appendChild(input);
    input.select();
    document.execCommand('copy');
    document.body.removeChild(input);
    alert('Link copied to clipboard!');
  }
</script>


<?php /*<script>
    document.addEventListener('DOMContentLoaded', function () {
        var shareButtons = document.querySelectorAll('.post-share-buttons a');

        // Add click event listeners to each share button
        shareButtons.forEach(function (button) {
            button.addEventListener('click', function (event) {
                event.preventDefault();

                var shareTitle = document.title;
                var shareUrl = window.location.href;

                if (button.classList.contains('share-twitter')) {
                    // Share on Twitter
                    var twitterUrl = 'https://twitter.com/intent/tweet?text=' + encodeURIComponent(shareTitle) + '&url=' + encodeURIComponent(shareUrl);
                    window.open(twitterUrl, '_blank');
                } else if (button.classList.contains('share-facebook')) {
                    // Share on Facebook
                    var facebookUrl = 'https://www.facebook.com/sharer/sharer.php?u=' + encodeURIComponent(shareUrl);
                    window.open(facebookUrl, '_blank');
                } else if (button.classList.contains('share-whatsapp')) {
                    // Share on WhatsApp
                    var whatsappUrl = 'whatsapp://send?text=' + encodeURIComponent(shareTitle + ' ' + shareUrl);
                    window.location.href = whatsappUrl;
                } else if (button.classList.contains('share-email')) {
                    // Share via Email
                    var mailtoUrl = 'mailto:?subject=' + encodeURIComponent(shareTitle) + '&body=' + encodeURIComponent(shareTitle + '\n\n' + shareUrl);
                    window.location.href = mailtoUrl;
                } else if (button.classList.contains('copy-link')) {
                    // Copy Link
                    var tempInput = document.createElement('input');
                    tempInput.value = shareUrl;
                    document.body.appendChild(tempInput);
                    tempInput.select();
                    document.execCommand('copy');
                    document.body.removeChild(tempInput);
                    alert('Link copied to clipboard!');
                }
            });
        });
    });
</script>
*/
//get_template_part( 'templates/social-share' ); 
}

?>
       
       
                  <?php 

                  if (get_theme_mod('display_comment_details', true)) {

                   // Display comments section
                  if (comments_open() || get_comments_number()) {
                    ?>
                    <div class="blog-card-group">

                     <div class="comment-card">
                      <div class="comments-section">

                        <div class="comment-form-container"><?php
                        comments_template();
                      ?> </div>
                    </div>
                  </div>
                </div>
                <?php
              }

            }
              ?>
               
       


</div>
<!--- ASIDE  -->

<?php get_sidebar(); ?>

</div>

</div>
</div>
<p class="info">This page was generated in <?php echo(number_format(microtime(true) - $start_time, 6)); ?> seconds.<p>
 
  
<style type="text/css">
    
    .bottom-content .settings{
      position: relative;
      float: right;
  }

  .settings .menu2{
      width:110px;
      z-index: 1;
      bottom: 0;
      right: -5px;
      padding: 5px;
      background: #fff;
      position: absolute;
      border-radius: 4px;
      transform: scale(0);
      transform-origin: bottom right;
      box-shadow: 0 0 6px rgba(0,0,0,0.15);
      transition: transform 0.2s ease;
  }
  .settings.show .menu2{
      transform: scale(1);
  }
  .settings .menu2 li{
      align-items: center;
      display:flex;
      height: 25px;
      font-size: 16px;
      padding: 15px;
      cursor: pointer;
      box-shadow: none;
      border-radius: 0;
      justify-content: flex-start;
  }

  .menu2 li:hover{
      background: #f5f5f5;
  }
  .menu2 li i{
      padding-right: 8px;
  }
  
  .popup header{
      display: flex;
      align-items: center;
      justify-content: space-between;
  }

  .popup-box{
      position: fixed;
      top: 0;
      left: 0;
      z-index: 2;
      height: 100%;
      width: 100%;
      background: rgba(0,0,0,0.4);
  }
  .popup-box .popup{
      position: absolute;
      top: 50%;
      left: 50%;
      z-index: 3;
      width: 100%;
      max-width: 400px;
      justify-content: center;
      transform: translate(-50%, -50%) scale(0.95);
  }
  .popup-box, .popup{
      opacity: 0;
      pointer-events: none;
      transition: all 0.25s ease;
  }
  .popup-box.show, .popup-box.show .popup{
      opacity: 1;
      pointer-events: auto;
  }
  .popup-box.show .popup{
      transform: translate(-50%, -50%) scale(1);
  }
  .popup .contenta{
      border-radius: 5px;
      background: #fff;
      width: calc(100% - 15px);
      box-shadow: 0 0 15px rgba(0,0,0,0.1);
  }
  .contenta header{
      padding: 15px 25px;
      border-bottom: 1px solid #ccc;
  }
  .contenta header p{
      font-size: 20px;
      font-weight: 500;
  }
  .contenta header i{
      color: #8b8989;
      cursor: pointer;
      font-size: 23px;
  }
  .contenta form{
      margin: 15px 25px 35px;
  }
  .contenta form .row{
      margin-bottom: 20px;
  }
  form .row label{
      font-size: 18px;
      display: block;
      margin-bottom: 6px;
  }

  @media (max-width: 660px){
      
      .popup-box .popup{
        max-width: calc(100% - 15px);
    }
}
</style>
</main>

<?php endwhile; ?>

<?php get_footer(); // Include the footer template ?>
