





<div class="darkMode-wrap">
  <button class="theme-btn theme-btn-desktop light">
    <i name="moon" class="moon fa fa-moon"></i>
    <i name="sunny" class="sun fa fa-sun"></i>
  </button>


</div>
<div id="scrollToTop" onclick="scrolltop();"><i class="fa fa-arrow-up"></i></div>



<hr>
<footer>

  <div class="container">

    <div class="wrapper">

      

      <p class="footer-text">
        Learn about Web accessibility, Web performance, and Database management.
        
      </p>

    </div>

    <div class="wrapper">

      <p class="footer-title">Quick Links</p>

      <ul>

        <li>
          <a href="#" class="footer-link">Advertise with us</a>
        </li>

        <li>
          <a href="#" class="footer-link">About Us</a>
        </li>

        <li>
          <a href="#" class="footer-link">Contact Us</a>
        </li>

      </ul>

    </div>

    <div class="wrapper">

      <p class="footer-title">Legal Stuff</p>

      <ul>

        <li>
          <a href="#" class="footer-link">Privacy Notice</a>
        </li>

        <li>
          <a href="#" class="footer-link">Cookie Policy</a>
        </li>

        <li>
          <a href="#" class="footer-link">Terms Of Use</a>
        </li>

      </ul>

    </div>

  </div>

  <p class="copyright">
    &copy; Copyright <a href="#">2023</a>
  </p>
  

</footer>


<?php wp_footer(); ?>
<!-- custom js link -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>