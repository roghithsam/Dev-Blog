<?php


get_header(); 


if ( is_home() && is_front_page() ) { 

	echo ' <style type="text/css">
  .hero { text-align: left; }

  .hero .container {
    display: grid;
    grid-template-columns: 1fr 1fr;
    align-items: center;
    gap: 50px;
  }

  .hero .btn-group {
    justify-content: start;
    gap: 30px;
  }

  .hero .right {
    position: relative;
    display:         flex;
    justify-content: center;
    align-items:     center;
  }

  .hero .pattern-bg {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    width: 100%;
    height: 200px;
    background: url('. get_template_directory_uri().'/assets/images//pattern.png);
    background-size: contain;
    opacity: 0.2;
  }

  .hero .img-box {
    position: relative;
    z-index: 2;
  }

  .hero-img {
    width:  100%;
    height: 100%;
    object-fit: contain;
    border-radius: 0 0 280px 230px;
    transform: translate(10px, -10px);
  }

  .hero .shape {
    position: absolute;
    top:  50%;
    left: 50%;
    border-radius: 50%;
    transform: translate(-50%, -42%) rotate(-20deg);
  }

  .hero .shape-1 {
    background: var(--accent);
    width:  90%;
    height: 90%;
    z-index: -1;
  }

  .hero .shape-2 {
    width:  92%;
    height: 92%;
    box-shadow: inset 0 -30px 0 var(--action-primary);
    z-index: 2;
  }

</style>
';?>
	

<main>

    <!-- #HERO SECTION -->
   

    <div class="hero">

      <div class="container">

        <div class="left">

          <h1 class="h1">
            Hey, Welcome to <b><?php echo get_bloginfo( 'name' ); ?></b>
            </h1>

          <p class="h3">
          <?php echo get_bloginfo( 'description' ); ?>
          </p>

          <div class="btn-group">
            <a href="./contact" class="btn btn-primary">Contact Me</a>
            <a href="./about" class="btn btn-secondary">About Me</a>
          </div>

        </div>

        <div class="right">

          <div class="pattern-bg"></div>
          <div class="img-box">
            <img src="<?= get_template_directory_uri(); ?>/assets/images/author1.png" alt="Roghithsam" class="hero-img">

            <div class="shape shape-1"></div>
            <div class="shape shape-2"></div>
          </div>

        </div>

      </div>

    </div>



    <div class="main">

      <div class="container">

        <!-- BLOG SECTION -->

           <!-- BLOG SECTION -->

<div class="blog">

	 <h2 class="h2">Latest Blog Post</h2>

	<div class="blog-card-group" id="loadData">

		<?php 
if ( have_posts() ) {
		while ( have_posts() ) {

			the_post(); 

			?>

			<div class="blog-card">

				<div class="blog-card-banner">

					<?php if (has_post_thumbnail()){ ?>

							<a href="<?php the_permalink(); ?>"></a>
							<?php 

							$thumbnail_attributes = array(
								'class' => 'blog-banner-img',
								'width' => '250',

							);
							the_post_thumbnail('thumbnail', $thumbnail_attributes);

						 }else{
						 	echo '<img src="'. get_template_directory_uri() .'/assets/images/ben.png" alt="' . get_bloginfo( 'name' ) . '"  width="250" class="blog-head-img">';
						 } ?>

				</div>

				<div class="blog-content-wrapper">


					<?php
					$categories = get_the_category();
					$cnt = 0; 
					foreach ($categories as $category) {
						$cnt += 1;
						if ($cnt <=2 ) {
						echo '<a href="' . esc_url(get_category_link($category->term_id)) . '"><button class="blog-topic text-tiny">' . $category->name . '</button></a> ';
					}
					}
					?>

					<h3>
						<a href="<?php the_permalink(); ?>" class="h3">
							<?php the_title(); ?>
						</a>
					</h3>

					<div class="blog-text">

						<?php 
							$excerpt = get_the_excerpt(); 
							$excerpt = substr( $excerpt, 0, 250 ); // Only display first 260 characters of excerpt
							$result = substr( $excerpt, 0, strrpos( $excerpt, ' ' ) );
						    echo $result; 
						    echo '<a class="pull-right" href="<?php the_permalink(); ?>"><span style="
							right: 5px; bottom: 5px;">Read more...</span></a>';
						?>
					</div>
					 <?php if (get_theme_mod('display_author_details', true)) { ?>
					<hr>
					<div class="wrapper-flex">

						<div class="profile-wrapper">
							<?php echo get_avatar(get_the_author_meta('user_email'), '50'); ?>
						</div>

						<div class="wrapper">
							<a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID')));   ?>" class="h4"> <?php the_author(); ?> </a>

						

							<p class="text-sm">
								<i class="fa fa-calendar"></i>
								<time><?php the_time('F j, Y'); ?> </time>
								<span class="separator"></span>
								<i class="fa fa-clock"></i>
								<time><?php the_time('g:i a'); ?></time>
							</p>
                            
							
						</div>

						

					</div>

					<?php }?>

				</div>

			</div>

			<?php

		} 
}
		?>


	</div>

</div>

        <!-- ASIDE -->

        <?php get_sidebar(); ?>

      </div>

    </div>

  </main>



<?php }  

get_footer();


?>