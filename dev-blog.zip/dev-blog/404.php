<?php
/**
 * The template for displaying the 404 template.
 *
 * @package WordPress
 * @subpackage Ben_Blog
 * @since Ben_Blog 1.0
 */

get_header();
?>

<main>
 
        <div class="main">

         <div class="container">

         <!-- BLOG SECTION -->

         <div class="blog">

          <div class="blog-card-group">

            <div class="blog-card">

              <style>

                .empty-2-1{
                  padding: 4rem 2rem 4rem;
                }
                .empty-2-1 .main-img{
                  object-fit: contain;
                  object-position: center;
                  margin-bottom: 3rem;
                  width: 75%;
                }

                .empty-2-1 .title-caption{
                  margin-bottom: 4rem;
                  letter-spacing: 0.025em;
                  line-height: 1.75rem;
                }

                @media(min-width: 425px){
                  .empty-2-1 .title-text{
                    font-size: 40px;
                  }
                }
                @media (min-width: 576px) {            
                  .empty-2-1{
                    padding-top: 5rem;
                  }
                  .empty-2-1 .main-img{
                    margin-bottom: 4rem;
                    width: auto;
                  }            
                }               
              </style>

              <div class="empty-2-1 container mx-auto d-flex align-items-center justify-content-center flex-column" style="font-family: 'Poppins', sans-serif;">    
                <img class="main-img" src="../assets/images/404.png" alt="404">   

        


                 <div>
                  <h1 class="title-text h1">
                   <?php _e( 'Oops! That page can’t be found.', 'twentyfifteen' ); ?>
                  </h1>
                  <?php
                  get_search_form(
                  	array(
                  		'aria_label' => __( '404 not found', 'benblog' ),
                  	)
                  );
                  ?>
                  <p class="title-caption blog-text">
                    The page you’re looking for isn’t found. We<br class="d-sm-block d-none"> suggest you Back to Homepage.
                  </p>
                  <div>
                    <a href="/"><button class="btn btn-primary">
                      Back to Homepage
                    </button></a>
                  </div>

                </div>

              </div>


            </div>

          </div>

         </div>

          <!-- SIDE -->

          <?php get_sidebar(); ?>
        
         </div>

    </div>

  </main>

<?php
get_footer();
 ?>