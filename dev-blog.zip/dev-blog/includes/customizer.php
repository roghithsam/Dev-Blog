<?php

// Register the customizer option
function customizer_options($wp_customize) {

  $wp_customize->add_section('archive_settings', array(
    'title' => 'Archive Settings',
    'priority' => 30,
  ));

  $wp_customize->add_setting('display_author_details', array(
    'default' => true,
    'transport' => 'refresh',
  ));

  $wp_customize->add_control('display_author_details', array(
    'type' => 'checkbox',
    'label' => 'Display Author Details',
    'section' => 'archive_settings',
  ));



  $wp_customize->add_section('post_settings', array(
    'title' => 'Post Settings',
    'priority' => 31,
  ));


  $wp_customize->add_setting('display_post_tags_details', array(
    'default' => true,
    'transport' => 'refresh',
  ));

  $wp_customize->add_control('display_post_tags_details', array(
    'type' => 'checkbox',
    'label' => 'Display Tags',
    'section' => 'post_settings',
  ));

  
  $wp_customize->add_setting('display_post_image_details', array(
    'default' => true,
    'transport' => 'refresh',
  ));

  $wp_customize->add_control('display_post_image_details', array(
    'type' => 'checkbox',
    'label' => 'Display Post Image',
    'section' => 'post_settings',
  ));

  $wp_customize->add_setting('display_post_next-pre_details', array(
    'default' => true,
    'transport' => 'refresh',
  ));

  $wp_customize->add_control('display_post_next-pre_details', array(
    'type' => 'checkbox',
    'label' => 'Display Previous and next buttons',
    'section' => 'post_settings',
  ));

   $wp_customize->add_setting('display_note_details', array(
    'default' => true,
    'transport' => 'refresh',
  ));

  $wp_customize->add_control('display_note_details', array(
    'type' => 'checkbox',
    'label' => 'Display Note Details',
    'section' => 'post_settings',
  ));

  $wp_customize->add_setting('display_related_post_details', array(
    'default' => true,
    'transport' => 'refresh',
  ));

  $wp_customize->add_control('display_related_post_details', array(
    'type' => 'checkbox',
    'label' => 'Display Related Post',
    'section' => 'post_settings',
  ));


  $wp_customize->add_setting('display_post_share_details', array(
    'default' => true,
    'transport' => 'refresh',
  ));

  $wp_customize->add_control('display_post_share_details', array(
    'type' => 'checkbox',
    'label' => 'Display Share Icons',
    'section' => 'post_settings',
  ));


  $wp_customize->add_setting('display_comment_details', array(
    'default' => true,
    'transport' => 'refresh',
  ));

  $wp_customize->add_control('display_comment_details', array(
    'type' => 'checkbox',
    'label' => 'Display Comment',
    'section' => 'post_settings',
  ));  


  


}
add_action('customize_register', 'customizer_options');

?>