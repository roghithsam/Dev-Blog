<div class="container">

  <nav class="navbar">

      <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
      <?php 

      $custom_logo_id = get_theme_mod( 'custom_logo' );
      $logo = wp_get_attachment_image_src( $custom_logo_id , 'full' );
      if ( has_custom_logo() ) {
        echo '<img src="' . esc_url( $logo[0] ) . '" alt="' . get_bloginfo( 'name' ) . '" width="150" height="40" class="logo-light">';
        echo '<img src="' . esc_url( $logo[0] ) . '" alt="' . get_bloginfo( 'name' ) . '" width="150" height="40" class="logo-dark">';
      } else {
        echo '<h1>' . get_bloginfo('name') . '</h1>';
      }
     ?>
    </a> 

    <div class="btn-group">

      <button class="theme-btn theme-btn-mobile light">
          <i name="moon" class="moon fa fa-moon"></i>
          <i name="sunny" class="sun fa fa-sun"></i>
      </button>

      <button class="nav-menu-btn">
         <i name="menu-outline" class="fa fa-list"></i>
      </button>

    </div>

    <div class="flex-wrapper">
<?php
wp_nav_menu(
  array(
    'theme_location'  => 'primary',
    'menu_class'      => 'desktop-nav',
    'container_class' => 'primary-menu-container',
    'items_wrap'      => '<ul class="%2$s">%3$s</ul>',
    'fallback_cb'     => false,
    'walker'          => new Custom_Nav_Walker(), 
  )
);
?>


      <ul class="desktop-nav">

        <li>
          <form  method="POST" action="search">
           <div class="searchBox" >
            <input class="searchInput" type="text" placeholder="Search" name="keyword" required="required">
            <button class="searchButton" name="search" >
              <i class="fa fa-search" aria-hidden="true">
              </i>
            </button>
            
          </div>
        </form>

      </li>

    </ul>


    <button class="theme-btn theme-btn-desktop light">
      <i name="moon" class="moon fa fa-moon"></i>
          <i name="sunny" class="sun fa fa-sun"></i>
    </button>

  </div>

  <div class="mobile-nav">

    <button class="nav-close-btn">
      <i class="fa fa-close"></i>
    </button>

    <div class="wrapper">
      <form  method="POST" action="search">
       <div class="searchBox" >
        <input class="searchInput" type="text" placeholder="Search" name="keyword" required="required">
        <button class="searchButton" name="search" >
          <i class="fa fa-search" aria-hidden="true">
          </i>
        </button>
        
      </div>
    </form>
    <br>

    <p class="h3 nav-title">Main Menu</p>


     <?php
    wp_nav_menu(
      array(
        'theme_location'  => 'mobile',
        'menu_class'      => 'nav-item',
        'container_class' => 'primary-menu-container',
        'items_wrap'      => '<ul class="%2$s">%3$s</ul>',
        'fallback_cb'     => false,
        'walker'          => new Custom_Nav_Walker(), 

      )
    );
    ?>

  </div>


</div>

</nav>

</div>