<div class="top-container">

    <div class="top-navbar">

      <div class="topbar-today-date tie-icon bw-text">
        <i class="fa fa-clock"></i><span> <?php the_time( ' F j, Y' ); ?></span>
      </div>

      
      <div class="btn-group flex-wrapper">

       <ul class="top-social-link">

         <li>
           <a href="#" class="icon-box discord">
             <i class="fab fa-discord"></i>
           </a>
         </li>

         <li>
           <a href="#" class="icon-box twitter">
             <i class="fab fa-twitter"></i>
           </a>
         </li>

         <li>
           <a href="#" class="icon-box facebook">
              <i class="fab fa-facebook"></i>
           </a>
         </li>

       </ul>
       
     </div>

     <?php /* its display  oonly on desktop Not on Mobile

       <div class="flex-wrapper">

         <ul class="top-social-link">

           <li>
             <a href="#" class="icon-boxa discord">
                <i class="fab fa-discord"></i>
             </a>
           </li>

           <li>
             <a href="#" class="icon-boxa twitter">
               <i class="fab fa-twitter"></i>
             </a>
           </li>

           <li>
             <a href="#" class="icon-boxa facebook">
                <i class="fab fa-facebook"></i>
             </a>
           </li>

         </ul>
         
       </div>*/?>


          
   </div>
   
 </div>

 
 <hr>
 
