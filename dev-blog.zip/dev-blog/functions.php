<?php


wp_enqueue_style( 'custom', get_template_directory_uri() . '/assets/css/custom.css', false, '1.0', 'all' );

wp_enqueue_style( 'style', get_template_directory_uri() . '/style.css', false, '1.0', 'all' );

wp_enqueue_script( 'script', get_template_directory_uri() . '/assets/js/custom.js', array( 'jquery' ), '1.1', true );

wp_enqueue_script( 'scripta', get_template_directory_uri() . '/assets/js/script.js', array( 'jquery' ), wp_get_theme()->get( 'Version' ), true );


require_once 'includes/customizer.php';

function register_my_menus() {
  register_nav_menus(
    array(
      'primary' => __( 'Primary Menu' ),
      'mobile' => __( 'Mobile Menu' ),
      'footer' => __( 'Footer Menu' )
     )
   );
 }
 add_action( 'init', 'register_my_menus' );

// Add custom class name to wp_nav_menu anchor tag
function add_custom_class_to_menu_link($atts, $item, $args) {
    // Check if the menu item has a custom class defined
    if (isset($item->classes) && in_array('custom-class', $item->classes)) {
        // Add your custom class name to the anchor tag attributes
        $atts['class'] = 'your-custom-class';
    }

    return $atts;
}
add_filter('nav_menu_link_attributes', 'add_custom_class_to_menu_link', 10, 3);




add_action( 'widgets_init', 'ben_register_sidebars' );
function ben_register_sidebars() {
  /* Register the 'primary' sidebar. */
  register_sidebar(
    array(
      'id'            => 'primary-sidebar',
      'name'          => __( 'Primary Sidebar' ),
      'description'   => __( 'A short description of the sidebar.' ),
      'before_widget' => '<div id="%1$s" class="widget %2$s">',
      'after_widget'  => '</div>',
      'before_title'  => '<h2 class="h3">',
      'after_title'   => '</h2>',
    )
  );
  register_sidebar( array(
    'name'          => __( 'Footer 1', 'theme_name' ),
    'id'            => 'footer1',
    'before_widget' => '<aside id="%1$s" class="widget %2$s">',
    'after_widget'  => '</aside>',
    'before_title'  => '<h3 class="widget-title">',
    'after_title'   => '</h3>',
  ) );
  register_sidebar( array(
    'name'          => __( 'Footer 2', 'theme_name' ),
    'id'            => 'footer2',
    'before_widget' => '<ul><li id="%1$s" class="widget %2$s">',
    'after_widget'  => '</li></ul>',
    'before_title'  => '<h3 class="widget-title">',
    'after_title'   => '</h3>',
  ) );
  register_sidebar( array(
    'name'          => __( 'Footer 3', 'theme_name' ),
    'id'            => 'footer3',
    'before_widget' => '<div id="%1$s" class="widget %2$s">',
    'after_widget'  => '</div>',
    'before_title'  => '<h3 class="widget-title">',
    'after_title'   => '</h3>',
  ) );
  register_sidebar(
        array(
            'name'          => __('Topics Widget Area', 'your-theme-textdomain'),
            'id'            => 'topics_widget_area',
            'description'   => __('Widget area for topics.', 'your-theme-textdomain'),
            'before_widget' => '<div class="wrapper topics">',
            'after_widget'  => '</div>',
            'before_title'  => '<h2 class="h2">',
            'after_title'   => '</h2>',
        )
    );

    register_sidebar(
        array(
            'name'          => __('Tags Widget Area', 'your-theme-textdomain'),
            'id'            => 'tags_widget_area',
            'description'   => __('Widget area for tags.', 'your-theme-textdomain'),
            'before_widget' => '<div class="wrapper tags">',
            'after_widget'  => '</div>',
            'before_title'  => '<h2 class="h2">',
            'after_title'   => '</h2>',
        )
    );

    register_sidebar(
        array(
            'name'          => __('Contact Widget Area', 'your-theme-textdomain'),
            'id'            => 'contact_widget_area',
            'description'   => __('Widget area for contact information.', 'your-theme-textdomain'),
            'before_widget' => '<div class="wrapper contact">',
            'after_widget'  => '</div>',
            'before_title'  => '<h2 class="h2">',
            'after_title'   => '</h2>',
        )
    );

    register_sidebar(
        array(
            'name'          => __('Social Links Widget Area', 'your-theme-textdomain'),
            'id'            => 'social_links_widget_area',
            'description'   => __('Widget area for social links.', 'your-theme-textdomain'),
            'before_widget' => '<div class="wrapper social-link">',
            'after_widget'  => '</div>',
            'before_title'  => '<h2 class="h2">',
            'after_title'   => '</h2>',
        )
    );

  /* Repeat register_sidebar() code for additional sidebars. */
}

function ben_one_the_posts_navigation() {
    the_posts_pagination(
      array(
        'before_page_number' => esc_html__( 'Page', 'benblog' ) . ' ',
        'mid_size'           => 0,
        'prev_text'          => sprintf(
          '%s <span class="nav-prev-text">%s</span>',
          wp_kses(
            __( 'Newer <span class="nav-short">posts</span>', 'benblog' ),
            array(
              'span' => array(
                'class' => array(),
              ),
            )
          )
        ),
        'next_text'          => sprintf(
          '<span class="nav-next-text">%s</span> %s',
          wp_kses(
            __( 'Older <span class="nav-short">posts</span>', 'benblog' ),
            array(
              'span' => array(
                'class' => array(),
              ),
            )
          )        ),
      )
    );
  }







class RandomQuotesWidget extends WP_Widget {
  public function __construct() {
    parent::__construct(
      'random_quotes_widget',
      'Random Quotes Widget',
      array('description' => 'Displays random quotes')
    );
  }

  public function widget($args, $instance) {
    echo $args['before_widget'];

    // Display widget title if set
    $title = apply_filters('widget_title', $instance['title']);
    if (!empty($title)) {
      echo $args['before_title'] . $title . $args['after_title'];
    }

    // Output quote content and refresh button
    echo '<div class="quote-container">';
    echo '<p class="quote-content"></p>';
    echo '<button class="quote-refresh-btn">Refresh</button>';
    echo '</div>';

    echo $args['after_widget'];
  }

  public function form($instance) {
    $title = !empty($instance['title']) ? $instance['title'] : '';
    ?>
    <p>
      <label for="<?php echo $this->get_field_id('title'); ?>">Title:</label>
      <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>">
    </p>
    <?php
  }

  public function update($new_instance, $old_instance) {
    $instance = array();
    $instance['title'] = (!empty($new_instance['title'])) ? sanitize_text_field($new_instance['title']) : '';

    return $instance;
  }
}


function register_random_quotes_widget() {
  register_widget('RandomQuotesWidget');
}




class Custom_Nav_Walker extends Walker_Nav_Menu {

    // Start the element output
    public function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
        $classes = empty($item->classes) ? array() : (array) $item->classes;

        // Check if the item has children
        $has_children = in_array('menu-item-has-children', $classes);

        $output .= '<li class="' . implode(' ', $classes) . '">';

        $attributes  = !empty($item->url) ? ' href="' . esc_url($item->url) . '"' : '';
        $item_output = $args->before;
        $item_output .= '<a' . $attributes . '>';

        // Add the title of the menu item
        $item_output .= $args->link_before . apply_filters('the_title', $item->title, $item->ID) . $args->link_after;

        // Add the dropdown icon if the item has children
        if ($has_children) {
            $item_output .= ' <i class="fa fa-chevron-down dropdown-icon"></i>';
        }

        $item_output .= '</a>';
        $item_output .= $args->after;

        $output .= apply_filters('walker_nav_menu_start_el', $item_output, $item, $depth, $args);
    }

    // Start the submenu output
    public function start_lvl(&$output, $depth = 0, $args = null) {
        $indent = str_repeat("\t", $depth);
        $output .= "\n$indent<ul class=\"sub-menu\">\n";
    }
}



 ?>



