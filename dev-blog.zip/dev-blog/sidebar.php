<aside class="aside">
    <?php
    // Display the 'Topics' widget area
    if (is_active_sidebar('primary-sidebar')) {
        ?><div class="wrapper bw-text "><?php
        dynamic_sidebar('primary-sidebar');
        ?></div><?php
    }
    ?>

     <?php
    // Display the 'Topics' widget area
    if (is_active_sidebar('topics_widget_area')) {
         ?><div class="bw-text"><?php
        dynamic_sidebar('topics_widget_area');
        ?></div><?php
    }
    ?>

    <?php
    // Display the 'Tags' widget area
    if (is_active_sidebar('tags_widget_area')) {

         ?><div class="bw-text"><?php
        dynamic_sidebar('tags_widget_area');
        ?></div><?php
    }
    ?>

    <?php
    // Display the 'Contact' widget area
    if (is_active_sidebar('contact_widget_area')) {
         ?><div class="bw-text"><?php
        dynamic_sidebar('contact_widget_area');
        ?></div><?php
    }
    ?>

    <?php
    // Display the 'Social Links' widget area
    if (is_active_sidebar('social_links_widget_area')) {
         ?><div class="bw-text"><?php
        dynamic_sidebar('social_links_widget_area');
        ?></div><?php
    }
    ?>
    <div class="wrapper bw-text">

       <div class="newsletter">
        <h2 class="h2">Newsletter</h2>
        <p>Subscribe to our newsletter:</p>
        <form action="#" method="post">
            <input type="email" name="email" placeholder="Your email" required>
            <button type="submit" class="btn-primary">Subscribe</button>
        </form>
        </div>
    </div>
  
</aside>


    
