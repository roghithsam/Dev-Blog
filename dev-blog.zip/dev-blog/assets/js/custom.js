function myMenu(clicked_id) {
  document.getElementById("myDropdown"+clicked_id).classList.toggle("show");
}

 $(document).ready(function(){
 $(window).scroll(function(){
 if ($(window).scrollTop() > 100) {
  $('#scrollToTop').fadeIn();
 } else {
  $('#scrollToTop').fadeOut();
 }
 });
});

function scrolltop()
{
 $('html, body').animate({scrollTop : 0},500);
}


jQuery(window).on('load', function() { 
  var $ = jQuery; 
  $('#preloader-wrapperaa').fadeOut('slow', function() { 
    $(this).remove(); 
  });
});




jQuery(function($) {
  // Function to get random quote from the API
  function getRandomQuote() {
    $.get('https://api.quotable.io/random', function(data) {
      $('.quote-content').text(data.content);
    });
  }

  // Get initial random quote on page load
  getRandomQuote();

  // Refresh button click event handler
  $('.quote-refresh-btn').on('click', function() {
    getRandomQuote();
  });
});
